/*
*/

#ifndef CHARGECLI_H
#define CHARGECLI_H

void ChargeCLIregister(void);

#endif

